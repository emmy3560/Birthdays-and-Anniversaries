#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*REFRENCES: Idea of using prompts from ->https://stackoverflow.com/questions/52471846/requesting-user-input-in-c*/
/*REFRENCES: Idea of display_entriesChronological also from stackoverflow*/
enum Months { Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sept, Oct, Nov, Dec };

/*structure represents the date of an occasion*/
typedef struct Date {
    enum Months month;//months of the year
    int day;
    int year;
} Date;

/*categories*/
enum Category { Family, Friend, Relative, Colleague, Person };

/*types*/
enum Type { Birthday, Wedding, Nameday, Other };

/*represents an entry in the database*/
typedef struct Occasion {
    char name[50]; // Increased name size to accommodate longer descriptions
    Date date;
    enum Category cat;
    enum Type type;
} Occasion;

/*stores entire database*/
typedef struct Database {
    size_t numMonths;/*stores number of months*/
    size_t* spaceinMonth;/*stores allocated space for each month*/
    Occasion** month; // Changed to a double pointer[2D array] for better dynamic allocation
} Database;

/*Initializes database with allocated memory*/
void Database_initialize(Database* db) {
    db->month = (Occasion**)malloc(db->numMonths * sizeof(Occasion*));
    db->spaceinMonth = (size_t*)calloc(db->numMonths, sizeof(size_t)); // Initialize to 0
    for (size_t i = 0; i < db->numMonths; i++) {
        db->month[i] = (Occasion*)malloc(db->spaceinMonth[i] * sizeof(Occasion));
    }
}

/*Adds a new entry to the database*/
void addEntry(Occasion entry, Database* db) {
    enum Months entryMonth = entry.date.month;
    size_t emptyLoc = 0;
    for (emptyLoc = 0; emptyLoc < db->spaceinMonth[entryMonth]; emptyLoc++) {
        if (db->month[entryMonth][emptyLoc].name[0] == '\0') {
            break;
        }
    }
    if (emptyLoc == db->spaceinMonth[entryMonth]) {
        /* Resize*/
        db->spaceinMonth[entryMonth] += 5;
        db->month[entryMonth] = (Occasion*)realloc(db->month[entryMonth], db->spaceinMonth[entryMonth] * sizeof(Occasion));
    }

    /* Allocate memory for the new entry*/
    /*db->month[entryMonth][emptyLoc] = (Occasion*)malloc(sizeof(Occasion));*/

    /* Copy the entry data*/
    strcpy(db->month[entryMonth][emptyLoc].name, entry.name);
    db->month[entryMonth][emptyLoc].cat = entry.cat;
    db->month[entryMonth][emptyLoc].type = entry.type;
    db->month[entryMonth][emptyLoc].date = entry.date;
}

/*Loads entries from a file into the database*/
int loadEntry(Occasion entry, char* realproject, Database* db) {
    FILE* fp;
    fp = fopen(realproject, "r");
    if (fp == NULL) {
        printf("File Reading Error\n");
        return -1;
    }
    int result = 0;

    while ((result = fscanf(fp, "%d %d %d %d %s\n", &entry.date.year,
                            &entry.date.month,
                            &entry.date.day,
                            &entry.cat,
                            &entry.name)) == 5) {

        addEntry(entry, db);
    }

    if (result < 5) {
        printf("Invalid format\n");
    }

    fclose(fp);

    return 0;
}

/*Saves entries from the database to a file*/
int saveEntry(Occasion entry, char* realproject, Database* db) {
    FILE* fp;
    int status;
    fp = fopen(realproject, "w");
    if (fp == NULL) {
        printf("File Writing Error\n");
        return 1;
    }

    for (size_t i = 0; i < db->numMonths; i++) {
        for (size_t j = 0; j < db->spaceinMonth[i]; j++) {
            if (db->month[entry.date.month][j].name[0] != '\0') {
                fprintf(fp, "%d %d %d %d %s\n", db->month[i][j].date.year,
                        db->month[i][j].date.month,
                        db->month[i][j].date.day,
                        db->month[i][j].cat,
                        db->month[i][j].name);
            }
        }
    }

    status = fclose(fp);
    if (status != 0)
        return 1;

    return 0;
}

/*Displays entries based on specified category*/
void displaycategoryentry(Occasion entry, Database* db) {
    printf("Enter desired category entry: ");
    scanf("%d", (int*)&entry.cat);

    if (entry.cat < 0 || entry.cat > 5) {
        printf("No Valid Category Entered\n");
        return;
    }

    int flag = 0;
    for (size_t j = 0; j < db->spaceinMonth[entry.date.month]; j++) {
        if (db->month[entry.date.month][j].cat == entry.cat) {
            flag = 1;
            printf("Date occurred: %d/%d/%d\n Category: %d\n Name: %s\n", db->month[entry.date.month][j].date.year,
                    db->month[entry.date.month][j].date.month + 1,
                    db->month[entry.date.month][j].date.day,
                    db->month[entry.date.month][j].cat,
                    db->month[entry.date.month][j].name);
            }
    }


    if (!flag)
        printf("No Matching Event\n");
}

/*Displays entries based on a specified day*/
void displaydayentry(Occasion entry, Database* db) {
    int flag = 0;
    printf("Enter desired day entry: ");
    scanf("%d", &entry.date.day);

        if (entry.date.day < 1 || entry.date.day > 31) {
        printf("No Valid Date Entered\n");
        return;
    }

    for (size_t j = 0; j < db->spaceinMonth[entry.date.month]; j++) {
        if (db->month[entry.date.month][j].date.day == entry.date.day) {
            flag = 1;
            printf("Date occurred: %d/%d/%d\n Category: %d\n Name: %s\n", db->month[entry.date.month][j].date.year,
                    db->month[entry.date.month][j].date.month + 1,
                    db->month[entry.date.month][j].date.day,
                    db->month[entry.date.month][j].cat,
                    db->month[entry.date.month][j].name);
            }
    }


    if (flag == 0)
        printf("No Matching Event\n");
}

/*Entries for a specific month and year*/
void display_Eventsinmonths(enum Months month, size_t year, Database* db) {
    if (month == Jan) {
        if (month == 0) {
            month = Dec;
            year--;
        }
    }
    else if (month > Dec) {
        month = Jan;
        year--;
    }

    for(size_t i = 0; i < db->spaceinMonth[month]; i++) {
            printf("Date occurred: %d/%d/%d\n Category: %d\n Name: %s\n",
                    db->month[month][i].date.year,
                    db->month[month][i].date.month + 1,
                    db->month[month][i].date.day,
                    db->month[month][i].cat,
                    db->month[month][i].name);
    }
}

/*Displays entries in chronological order*/
void display_entriesChronological(Database* db) {
    enum Months currentmonth = Jan;
    size_t currentyear = 1999;

    printf("Events of last month: ");
    display_Eventsinmonths(currentmonth - 1, currentyear, db);

    printf("Events in Next month: ");
    display_Eventsinmonths(currentmonth + 1, currentyear, db);
}

/*prompt for a user to add an entry*/
void handleaddEntry(Occasion* entry) {
    printf("Enter event details:\n");

    printf("Name (up to 49 characters): ");
    scanf("%s", entry->name);

    printf("Date (day month year): ");
    scanf("%d %d %d",&entry->date.day, &entry->date.month, &entry->date.year);

    printf("Category (0 for Family, 1 for Friend, 2 for Relative, 3 for Colleague, 4 for Person): ");
    scanf("%d", (int*)&entry->cat);

    printf("Type (0 for Birthday, 1 for Wedding, 2 for Nameday, 3 for Other): ");
    scanf("%d", (int*)&entry->type);
}

/*prompt for a user to load an entry*/
int handleLoadEntry(Occasion* entry, Database* db) {
    char fileName[50];
    printf("Enter the file name for loading entries: ");
    scanf("%s", fileName);

    int result = loadEntry(*entry, fileName, db);

    if (result == 0) {
        printf("Entries loaded successfully!\n");
    } else {
        printf("Failed to load entries from the file.\n");
    }

    return result;
}

/*prompt for a user to save an entry*/
int handleSaveEntry(Occasion* entry, Database* db) {
    int result = saveEntry(*entry, "realproject.txt", db);

    if (result == 0) {
        printf("Entries saved successfully!\n");
    } else {
        printf("Failed to save entries to the file.\n");
    }

    return result;
}

/*Displays main menu of the program */
void main_menu() {
    printf("1. Add an entry\n"
           "2. Save an entry\n"
           "3. Load database\n"
           "4. Display entry category\n"
           "5. Display day entry\n"
           "6. Display entries in chronological order\n"
           "0. Close the program\n");
}

/*main function of the program*/
int main() {
    Database db = { 12, NULL };
    printf("Enter the number of events for each month: ");
    scanf("%d", &db.numMonths);

    // Allocate memory for spaceinMonth based on user input
    db.spaceinMonth = (size_t*)calloc(db.numMonths, sizeof(size_t));

    Database_initialize(&db);

    Occasion newEntry;
    int choice;

    do {
        main_menu();
        printf("Enter your choice: ");
        scanf("%d", &choice);
/*using switch case to call the different functions */
         switch (choice) {
            case 1:
                handleaddEntry(&newEntry);
                addEntry(newEntry, &db);
                break;
            case 2:
                handleSaveEntry(&newEntry, &db);
                /*saveEntry(newEntry, "realproject.txt", &db);*/
                break;
            case 3:
                handleLoadEntry(&newEntry, &db);
                /*loadEntry(newEntry, "realproject.txt", &db);*/
                break;
            case 4:
                displaycategoryentry(newEntry, &db);
                break;
            case 5:
                displaydayentry(newEntry, &db);
                break;
            case 6:
                display_entriesChronological(&db);
                break;
            case 0:
                printf("Closing the program!!\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    } while (choice != 0);

    // Free allocated memory before exiting the program
    for (size_t i = 0; i < db.numMonths; i++) {
        for (size_t j = 0; j < db.spaceinMonth[i]; j++) {
            free(db.month[j]);
        }
        free(db.month[i]);
    }
    free(db.month);
    free(db.spaceinMonth);

    return 0;
}
